/*
* Title: Loan Account Class
* Author: James Taddei
* Date: 2023-08-30
* Dscription:
*   This class takes a principle loan amount and determines the monthly payments
*   at a given annual interest rate.
*/

package programmingassignment1;

// Account for each loan
public class LoanAccount {
    // Class variable declarations
    private static double annualInterestRate;
    private double principle;
    
    public LoanAccount(double principle) {
        // Constructor
        this.principle = principle;
    }
    
    public double calculateMonthlyPayment(int numberOfPayments) {
        // Returns the monthly payment required for the loan given the number
        // of payments.
        
        // Calculates the monthly payment value
        double monthlyInterest = annualInterestRate / 12;
        double monthlyPayment = principle * ( monthlyInterest / (1 - Math.pow(1 + monthlyInterest, -numberOfPayments)));
        
        return monthlyPayment;
    }
    
    public static void setAnnualInterestRate(double annualInterestRate) {
        // Sets the annual interest rate
        LoanAccount.annualInterestRate = annualInterestRate;
    }
}
